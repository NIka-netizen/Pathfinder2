#include "../inc/pathfinder.h"

void find_path(int *weights, char **islands, t_link **bridges, int num_islands)
{
    char **visited = malloc(num_islands * sizeof *visited);
    char *cur;
    int moves = 0;
    int weight = 0;
    int i = 0;
    while (i < num_islands)
    {
        int min = 0;
        int n = true;
        while (n)
        {
            int m = 0;
            n = false;
            while (m < moves)
            {
                if (!mx_strcmp(visited[m], islands[min]))
                {
                    n = true;
                    break;
                }
                m++;
            }
            min++;
        }
        if (moves == num_islands)
            break;
        for (int j = 0; j < num_islands; j++)
        {
            int m = 0;
            n = false;
            while (m < moves)
            {
                if (!mx_strcmp(visited[m], islands[j]))
                {
                    n = true;
                    break;
                }
                m++;
            }
            if (n)
                continue;
            if (weights[j] >= 0 && (weights[min] < 0 || weights[min] > weights[j]))
            {
                min = j;
            }
        }
        cur = islands[min];
        for (int j = 0; bridges[j] != NULL; j++)
        {
            if (!mx_strcmp(bridges[j]->first, cur))
            {
                int m = 0;
                n = false;
                while (m < moves)
                {
                    if (!mx_strcmp(visited[m], bridges[j]->second))
                    {
                        n = true;
                        break;
                    }
                    m++;
                }
                if (n)
                    continue;
                weight = get_weight(islands, weights, cur);
                set_weight(&weights, islands, bridges[j]->second, weight + bridges[j]->weight);
            }
            else if (!mx_strcmp(bridges[j]->second, cur))
            {
                int m = 0;
                n = false;
                while (m < moves)
                {
                    if (!mx_strcmp(visited[m], bridges[j]->first))
                    {
                        n = true;
                        break;
                    }
                    m++;
                }
                if (n)
                    continue;
                for (int i = 0; islands[i] != NULL; i++)
                {
                    if (!mx_strcmp(islands[i], cur))
                        weight = weights[i];
                }
                set_weight(&weights, islands, bridges[j]->first, weight + bridges[j]->weight);
            }
        }
        visited[moves] = cur;
        moves++;
        i++;
    }
    free(visited);
}
