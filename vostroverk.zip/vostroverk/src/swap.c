#include "../inc/pathfinder.h"

t_link *swap (t_link **bridges, char **islands){
    t_link *buf;
    int i = 0;
    while (bridges[i] != NULL)
    {
        int j = i + 1;
        while (bridges[j] != NULL)
        {
            if (get_index(islands, bridges[i]->first) +
                get_index(islands, bridges[i]->second) >
                get_index(islands, bridges[j]->first) +
                get_index(islands, bridges[j]->second))
            {
                buf = bridges[i];
                bridges[i] = bridges[j];
                bridges[j] = buf;
            }
            j++;
        }
        i++;
    }
    return *bridges;
}
