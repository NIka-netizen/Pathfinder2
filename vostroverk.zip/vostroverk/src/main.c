#include "../inc/pathfinder.h"

int main(int argc, char *argv[])
{
    errors(argc, argv);
    path(argv);
}
