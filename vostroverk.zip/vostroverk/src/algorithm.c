#include "../inc/pathfinder.h"

void algorithm(t_link **bridges, char **islands, int num_islands, int num_bridges)
{
    swap(bridges, islands);
    int *weights_of_islands = malloc((num_islands + 1) * sizeof(int));
    for (int i = 0; i < num_islands - 1; i++)
    {
        for (int j = i + 1; j < num_islands; j++)
        {
            for (int k = 0; k < num_islands; k++)
                weights_of_islands[k] = -1;
            set_weight(&weights_of_islands, islands, islands[j], 0);
            find_path(weights_of_islands, islands, bridges, num_islands);
            print_path(weights_of_islands, islands, bridges, num_islands, islands[i], num_bridges);
        }
    }
    for (int i = 0; (bridges)[i] != NULL; i++)
    {
        mx_strdel(&(bridges)[i]->first);
        mx_strdel(&(bridges)[i]->second);
        free((bridges)[i]);
    }
    bridges = NULL;
    mx_del_strarr(&islands);
}
