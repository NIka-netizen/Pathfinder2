#include "../inc/pathfinder.h"

int get_path(int *length, int *weights, char **islands, t_link **bridges, int count, char *first, char **path, int *blocklist, int *block, int *count_block)
{
    int len, start_point_weight;
    int dist = -1;
    int moves = 1;
    char *first_is = first;
    int prev_bridge_index = -1;
    path[0] = first;
    int needed_bridge = -1;
    bool flag = true;
    for (int j = 0; j < count + 1 && flag; j++)
    {
        bool f = true;
        for (int i = 0; islands[i] != NULL; i++)
        {
            if (!mx_strcmp(islands[i], first))
                start_point_weight = weights[i];
        }
        for (int i = 0; bridges[i] != NULL; i++)
        {
            bool m = false;
            int k = 0;
            while (k < *block)
            {
                if (blocklist[k] == i)
                    m = true;
                k++;
            }
            if (m)
            {
                continue;
            }
            if (!mx_strcmp(bridges[i]->first, first))
            {
                first_is = bridges[i]->second;
                dist = get_weight(islands, weights, bridges[i]->second);
                len = bridges[i]->weight;
            }
            else if (!mx_strcmp(bridges[i]->second, first))
            {
                first_is = bridges[i]->first;
                dist = get_weight(islands, weights, bridges[i]->first);
                len = bridges[i]->weight;
            }
            if (dist == 0)
            {
                blocklist[*block] = i;
                *block += 1;
                path[moves] = first_is;
                length[moves - 1] = len;
                moves++;
                flag = false;
                f = false;
                needed_bridge = i;
                break;
            }
            if (start_point_weight - len == dist)
            {
                prev_bridge_index = i;
                length[moves - 1] = len;
                first = first_is;
                path[moves] = first;
                moves++;
                f = false;
                break;
            }
        }
        if (f == true)
        {
            if (!mx_strcmp(first, path[0]))
            {
                return -1;
            }
            j = 0;
            first = path[0];
            moves = 1;
            blocklist[*block] = prev_bridge_index;
            *block += 1;
            if (!mx_strcmp(bridges[prev_bridge_index]->first, path[0]) || !mx_strcmp(bridges[prev_bridge_index]->second, path[0]))
            {
                blocklist[*count_block] = prev_bridge_index;
                *count_block += 1;
                *block = *count_block;
            }
        }
        if (!flag && (!mx_strcmp(bridges[needed_bridge]->first, path[0]) || !mx_strcmp(bridges[needed_bridge]->second, path[0])))
        {
            blocklist[*count_block] = needed_bridge;
            *count_block += 1;
            *block = *count_block;
        }
    }
    path[moves] = NULL;
    return moves;
}
