#ifndef PATHFINDER_H_
#define PATHFINDER_H_

#include "../libmx/inc/libmx.h"

typedef struct s_link
{
    int weight;
    char *first;
    char *second;
} t_link;

void errors(int argc, char *argv[]);
int get_index(char **all_of_islands, char *one_of_island);
t_link *swap (t_link **bridges, char **islands);
void path(char *argv[]);
bool is_unic(char *island, char **islands);
int num_of_bridges(t_list *bridges);
int num_vershin(t_list *is_unic);
char *dub_string(char *s);
void mx_print_err(const char *s);
t_link *split_the_links(const char *s);
void algorithm(t_link **bridges, char **islands, int num_islands, int num_bridges);
void set_weight(int **weights, char **nodes, char *s, int waight);
void find_path(int *weights, char **nodes, t_link **bridges, int count);
void print_path(int *weights, char **nodes, t_link **bridges, int count, char *from, int bridge_count);
int get_path(int *len, int *weights, char **nodes, t_link **bridges, int count, char *from, char **path, int *blacklist, int *block, int *permo_block);
int get_weight(char **islands, int *weights, char *s);
bool blacklisted(int c, int *blacklist, int size);

#endif
