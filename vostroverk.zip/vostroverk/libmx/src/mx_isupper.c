#include "../inc/libmx.h"

bool mx_isupper(int c){
	return (c >= 65 && c <= 90);
}
